


class CustomClass {
    
    
    invoke() {
        return "CUSTOM FUNCTION THIS IS."    
    }

    
}

module.exports = CustomClass

